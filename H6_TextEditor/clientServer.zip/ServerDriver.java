


public class ServerDriver {

    public static void main(String[] args) throws Exception {

        ClientProxy.getInstance().begin();   
    }
}