
//used as a means of attaching one element to another for updates on the second element's content
public interface Observer {

    public void update();

}