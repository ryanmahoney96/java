
public class FileErrorException extends Exception{

    public FileErrorException(){
        super();
    }
    public FileErrorException(String message){
        super(message);
    }

}